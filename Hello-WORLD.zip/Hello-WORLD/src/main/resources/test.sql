insert into sys.country values(1,"1");
insert into sys.country values(2,"2");